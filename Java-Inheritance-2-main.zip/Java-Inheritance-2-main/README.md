Java Inheritance 2
